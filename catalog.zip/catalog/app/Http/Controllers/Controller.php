<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\Storage;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function search(Request $request)
    {
        $file = fopen(storage_path("databases/database.txt"), "r");
        $result = collect([]);
        while (!feof($file)) {
            $item = fgets($file);
            $itemArray = explode(',', $item);
            if (count($itemArray) > 1 && substr($itemArray[4],0,-1) === $request->input('topic'))
                $result->push(['id' => $itemArray[0], 'title' => $itemArray[1]]);
        }
        fclose($file);
        if (count($result) > 0)
            echo json_encode($result);
        else
            echo json_encode("No topic with such name!");
    }

    public function lookUp(Request $request)
    {
        $file = fopen(storage_path("databases/database.txt"), "r");
        $fount = false;
        $result = collect([]);
        while (!feof($file)) {
            $item = fgets($file);
            $itemArray = explode(',', $item);
            if (intval($itemArray[0]) === intval($request->input('id'))) {
                echo json_encode(['id' => $itemArray[0], 'title' => $itemArray[1], 'stock' => $itemArray[2], 'price' => $itemArray[3], 'topic' => $itemArray[4]]);
                $fount = true;
                break;
            }
        }
        if(!$fount)
            echo json_encode("No book with such id!");
        fclose($file);
    }

    public function buy(Request $request)
    {
        try {
            if ($request->input('op') == 'q') { //query request
                $file = fopen(storage_path("databases/database.txt"), "r");
                $lineNo = 0;
                $newText = "";
                $writeFlag = "";
                $found = false;
                while (!feof($file)) {
                    $lineNo++;
                    $item = fgets($file);
                    $itemArray = explode(',', $item);
                    if (intval($itemArray[0]) === intval($request->id)) {
                        $found = true;
                        if (intval($itemArray[2]) > 0) {
                        $newStock = intval($itemArray[2]);
                        $writeFlag = true;
                        return json_encode($newStock);
                        }
                        else{
                            $newText = $newText.$item;
                            $writeFlag = false;
                        }
                    }
                    else {
                        $newText = $newText.$item;
                    }
                }
                fclose($file);
                if(!$found)
                    return "No book with such id!";
                else if ($writeFlag === true)
                    return "Successfully bought!";
                else if ($writeFlag === false)
                    return "This book is out of stock!";
            }

            else { //Update request
                $file = fopen(storage_path("databases/database.txt"), "r");
                $lineNo = 0;
                $newText = "";
                while (!feof($file)) {
                    $lineNo++;
                    $item = fgets($file);
                    $itemArray = explode(',', $item);
                    if (intval($itemArray[0]) === intval($request->id)) {
                        if (intval($itemArray[2]) > 0) {
                            $newStock = $request->input('val');
                            $newText = $newText.$itemArray[0].",".$itemArray[1].",".$newStock.",".$itemArray[3].",".$itemArray[4];
                        }
                        else{
                            $newText = $newText.$item;
                        }
                    }
                    else {
                        $newText = $newText.$item;
                    }
                }
                fclose($file);
                $file = fopen(storage_path("databases/database.txt"), "w");
                fwrite($file,$newText);
                fclose($file);
                echo "Successfully bought!";
            }
        }catch (GuzzleHttp\Exception\ServerException $e) {
            $response = $e->getResponse();
            echo $responseBodyAsString = $response->getBody()->getContents();
        }
    }
}
