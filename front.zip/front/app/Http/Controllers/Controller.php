<?php

namespace App\Http\Controllers;


use GuzzleHttp\Client;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;
use Ixudra\Curl\Facades\Curl;
use test\Mockery\CallableSpyTest;
use Illuminate\Support\Facades\Storage;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
    private $catalogFlag;
    private $orderFlag;

    public function __construct()
    {
        if (session('catalogFlag') == null)
            session(['catalogFlag' => false]);
        if (session('orderFlag') == null)
            session(['orderFlag' => false]);
    }

    public function search(Request $request)
    {
        $file = fopen(storage_path("cache.txt"), "r"); //check if the request already cached
        while (!feof($file)) {
            $item = fgets($file);
            $itemArray = explode(';', $item);
            if ($itemArray[0] === 'search')
                if ($itemArray[1] === $request->input('topic')) {
                    echo $itemArray[2];
                    echo "from cache";
                    fclose($file);
                    return;
                }
        }
        $client = new Client();
        try {// for load balancing purposes, requests are splited between both servers equally
            if (!session('catalogFlag')) {
                session(['catalogFlag' => !session('catalogFlag')]);
                $response = $client->request('GET', '192.168.1.103:8000/search?topic=' . $request->input('topic'));
            } else {
                session(['catalogFlag' => !session('catalogFlag')]);
                $response = $client->request('GET', '192.168.1.104:8000/search?topic=' . $request->input('topic'));
            }


            $linecount = 0;
            $file = fopen(storage_path("cache.txt"), "r");
            while(!feof($file)){
                $line = fgets($file);
                $linecount++; //number of cached responses
            }
            fclose($file);
            if ($linecount === 6) {  //cache no more than 5 responses, if it's full remove first received response
                $file = fopen(storage_path("cache.txt"), "r");
                $newText = "";
                $isFirstLine = true;
                while (!feof($file)) {
                    $item = fgets($file);
                    if ($isFirstLine){
                        $isFirstLine= false;
                        continue;
                    }
                    $newText = $newText . $item;
                }
                fclose($file);
                $file = fopen(storage_path("cache.txt"), "w");
                fwrite($file, $newText);
                fclose($file);
            }
            $file = fopen(storage_path("cache.txt"), "a");  //to cache the response received
            $newText = "search;".$request->input('topic').";".$response->getBody()."\n";
            fwrite($file, $newText);
            fclose($file);
            echo $response->getBody();
        } catch (GuzzleHttp\Exception\ServerException $e) {
            $response = $e->getResponse();
            echo $responseBodyAsString = $response->getBody()->getContents();
        }
    }

    public function lookUp(Request $request)
    {
        $file = fopen(storage_path("cache.txt"), "r");
        while (!feof($file)) {
            $item = fgets($file);
            $itemArray = explode(';', $item);
            if ($itemArray[0] === 'lookup')
                if (intval($itemArray[1]) === intval($request->input('id'))) {
                    echo $itemArray[2];
                    echo "from cache";
                    fclose($file);
                    return;
                }
        }

        $client = new Client();
        if (!session('catalogFlag')) {
            session(['catalogFlag' => !session('catalogFlag')]);
            $response = $client->request('GET', '192.168.1.103:8000/lookup?id=' . $request->input('id'));
        } else {
            session(['catalogFlag' => !session('catalogFlag')]);
            $response = $client->request('GET', '192.168.1.104:8000/lookup?id=' . $request->input('id'));
        }


        $linecount = 0;
        $file = fopen(storage_path("cache.txt"), "r");
        while(!feof($file)){
            $line = fgets($file);
            $linecount++;
        }
        fclose($file);
        if ($linecount === 6) {
            $file = fopen(storage_path("cache.txt"), "r");
            $newText = "";
            $isFirstLine = true;
            while (!feof($file)) {
                $item = fgets($file);
                if ($isFirstLine){
                    $isFirstLine= false;
                    continue;
                }
                $newText = $newText . $item;
            }
            fclose($file);
            $file = fopen(storage_path("cache.txt"), "w");
            fwrite($file, $newText);
            fclose($file);
        }
        $file = fopen(storage_path("cache.txt"), "a");
        $newText = "lookup;".$request->input('id').";".$response->getBody()."\n";
        fwrite($file, $newText);
        fclose($file);
        echo $response->getBody();
    }

    public function buy(Request $request)
    {
        $client = new Client();
        if (!session('orderFlag')) {
            session(['orderFlag' => !session('orderFlag')]);
            $response = $client->request('POST', '192.168.1.105:8000/api/buy', [
                'form_params' => [
                    'id' => $request->input('id'),
                ]
            ]);
        } else {
            session(['orderFlag' => !session('orderFlag')]);
            $response = $client->request('POST', '192.168.1.108:8000/api/buy', [
                'form_params' => [
                    'id' => $request->input('id'),
                ]
            ]);
        }


        if (json_decode($response->getBody()) === json_encode("Successfully bought!")) { //delete bought item from cache
            $file = fopen(storage_path("cache.txt"), "r");
            $newText = "";
            while (!feof($file)) {
                $item = fgets($file);
                $itemArray = explode(';', $item);
                if ($itemArray[0] === 'lookup')
                    if (intval($itemArray[1]) === intval($request->input('id'))) {
                        continue;
                    }
                $newText = $newText . $item;
            }
            fclose($file);
            $file = fopen(storage_path("cache.txt"), "w");
            fwrite($file, $newText);
            fclose($file);
        }

        $linecount = 0;
        $file = fopen(storage_path("cache.txt"), "r");
        while(!feof($file)){
            $line = fgets($file);
            $linecount++;
        }
        fclose($file);
        if ($linecount === 6) {
            $file = fopen(storage_path("cache.txt"), "r");
            $newText = "";
            $isFirstLine = true;
            while (!feof($file)) {
                $item = fgets($file);
                if ($isFirstLine){
                    $isFirstLine= false;
                    continue;
                }
                $newText = $newText . $item;
            }
            fclose($file);
            $file = fopen(storage_path("cache.txt"), "w");
            fwrite($file, $newText);
            fclose($file);
        }
        $file = fopen(storage_path("cache.txt"), "a");
        $newText = "buy;".$request->input('id').";".$response->getBody()."\n";
        fwrite($file, $newText);
        fclose($file);
        echo $response->getBody();
    }
}
