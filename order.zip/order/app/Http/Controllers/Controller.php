<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;
use GuzzleHttp\Client;
use PhpParser\Node\Expr\Cast\String_;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function buy(Request $request)
    {
        $client = new Client();
        $response = $client->request('POST', '192.168.1.103:8000/api/buy', [ // query and get the amount/response
            'form_params' => [
                'id' => $request->id,
                'op' => 'q',
            ]
        ]);
        $res = (String)$response->getBody();
        if ($res == 'No book with such id!') {
            echo "No book with such id!";
        }
        else if ($res == 'This book is out of stock!') {
            echo "This book is out of stock!";
        }
        else { //found and in stock
            $res = (String)$response->getBody();
            $newStock = (int)$res-1;
            $response = $client->request('POST', '192.168.1.103:8000/api/buy', [ //update on first catalog
                'form_params' => [
                    'id' => $request->id,
                    'val' => $newStock,
                    'op' => 'u',
                ]
            ]);
            $response = $client->request('POST', '192.168.1.104:8000/api/buy', [ //update on second catalog
                'form_params' => [
                    'id' => $request->id,
                    'val' => $newStock,
                    'op' => 'u',
                ]
            ]);
            echo $response->getBody();
        }

    }
}
